import json
import os
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.request import Request, urlopen
from urllib.error import HTTPError, URLError

API_KEY = os.environ.get("OPENAI_API_KEY")
MODEL = os.environ.get("OPENAI_MODEL", "gpt-6-luna")
if not API_KEY:
    raise SystemExit("Set OPENAI_API_KEY in Termux before starting JARVIS.")

SYSTEM = (
    "You are JARVIS, a helpful personal AI assistant with a polished, calm, "
    "witty but respectful personality inspired by a fictional high-tech assistant. "
    "Speak naturally in conversational Hinglish, preferably Roman Hinglish so it "
    "sounds natural when spoken aloud. Keep replies concise unless asked for detail. "
    "Address the user politely as Sir when natural, but do not overuse it. "
    "Be honest about limitations. Never claim to have performed a phone action "
    "unless an implemented tool actually confirms it. Never ask for passwords, OTPs, "
    "or payment credentials."
)

history = {}

class Handler(BaseHTTPRequestHandler):
    def send_json(self, code, payload):
        data = json.dumps(payload).encode("utf-8")
        self.send_response(code)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(data)))
        self.send_header("Access-Control-Allow-Origin", "*")
        self.end_headers()
        self.wfile.write(data)

    def do_GET(self):
        if self.path == "/health":
            return self.send_json(200, {"status": "ok", "model": MODEL})
        return self.send_json(404, {"error": "Not found"})

    def do_POST(self):
        if self.path != "/ask":
            return self.send_json(404, {"error": "Not found"})
        try:
            length = int(self.headers.get("Content-Length", "0"))
            if length < 1 or length > 12000:
                return self.send_json(400, {"error": "Invalid request size"})
            body = json.loads(self.rfile.read(length).decode("utf-8"))
            sid = str(body.get("session_id", "default"))[:80]
            question = str(body.get("text", "")).strip()
            if not question or len(question) > 4000:
                return self.send_json(400, {"error": "Please send a short voice message."})

            messages = history.setdefault(sid, [])
            messages.append({"role": "user", "content": question})
            # Keep only a small recent context window.
            messages[:] = messages[-10:]
            request_body = {
                "model": MODEL,
                "instructions": SYSTEM,
                "input": messages
            }
            req = Request(
                "https://api.openai.com/v1/responses",
                data=json.dumps(request_body).encode("utf-8"),
                headers={
                    "Authorization": "Bearer " + API_KEY,
                    "Content-Type": "application/json"
                },
                method="POST"
            )
            with urlopen(req, timeout=60) as response:
                result = json.loads(response.read().decode("utf-8"))

            answer = ""
            for item in result.get("output", []):
                if item.get("type") == "message":
                    for content in item.get("content", []):
                        if content.get("type") == "output_text":
                            answer += content.get("text", "")
            answer = answer.strip() or "Maaf kijiye Sir, mujhe jawab nahi mil paaya."
            messages.append({"role": "assistant", "content": answer})
            return self.send_json(200, {"reply": answer})

        except HTTPError as e:
            print("OpenAI HTTP error:", e.code, e.read().decode("utf-8", "replace")[:1000])
            return self.send_json(502, {"error": "AI API request failed. Check API key, model access, and billing."})
        except (URLError, TimeoutError) as e:
            print("Network error:", repr(e))
            return self.send_json(502, {"error": "Network connection failed."})
        except Exception as e:
            print("Backend error:", repr(e))
            return self.send_json(500, {"error": "Backend error. Check Termux output."})

    def log_message(self, fmt, *args):
        print(fmt % args)

if __name__ == "__main__":
    server = ThreadingHTTPServer(("0.0.0.0", 8000), Handler)
    print("JARVIS backend listening on 0.0.0.0:8000")
    print("Keep Termux running while using the JARVIS Android app.")
    server.serve_forever()
