package com.example.jarvis

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.Locale
import java.util.UUID
import java.util.concurrent.Executors

class MainActivity : Activity(), TextToSpeech.OnInitListener {
    private val executor = Executors.newSingleThreadExecutor()
    private lateinit var status: TextView
    private lateinit var startButton: Button
    private lateinit var stopButton: Button
    private var recognizer: SpeechRecognizer? = null
    private var tts: TextToSpeech? = null
    private var sessionActive = false
    private var ttsReady = false
    private val sessionId = UUID.randomUUID().toString()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(4, 12, 28)
        window.navigationBarColor = Color.rgb(4, 12, 28)
        buildScreen()
        tts = TextToSpeech(this, this)
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            setStatus("Speech recognition service nahi mila. Phone settings check karein.")
        }
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO)
            != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.RECORD_AUDIO), 100)
        } else createRecognizer()
    }

    private fun buildScreen() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(28, 32, 28, 32)
            setBackgroundColor(Color.rgb(4, 12, 28))
        }
        val title = TextView(this).apply {
            text = "J.A.R.V.I.S."
            textSize = 30f
            setTextColor(Color.rgb(105, 211, 255))
            typeface = Typeface.create("sans-serif-light", Typeface.NORMAL)
            gravity = Gravity.CENTER
        }
        val subtitle = TextView(this).apply {
            text = "PERSONAL VOICE ASSISTANT"
            textSize = 11f
            letterSpacing = 0.22f
            setTextColor(Color.LTGRAY)
            gravity = Gravity.CENTER
        }
        val orb = TextView(this).apply {
            text = "◉"
            textSize = 76f
            gravity = Gravity.CENTER
            setTextColor(Color.rgb(105, 211, 255))
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(Color.rgb(10, 39, 67))
                setStroke(3, Color.rgb(35, 143, 204))
            }
        }
        status = TextView(this).apply {
            text = "Ready, Sir. Start listening when you're ready."
            textSize = 16f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            setPadding(12, 28, 12, 28)
        }
        startButton = Button(this).apply {
            text = "START LISTENING"
            setOnClickListener { startSession() }
        }
        stopButton = Button(this).apply {
            text = "STOP"
            isEnabled = false
            setOnClickListener { stopSession() }
        }
        root.addView(title)
        root.addView(subtitle)
        root.addView(orb, LinearLayout.LayoutParams(220, 220).apply { topMargin = 54; bottomMargin = 18 })
        root.addView(status)
        root.addView(startButton)
        root.addView(stopButton)
        setContentView(root)
    }

    private fun createRecognizer() {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) return
        recognizer?.destroy()
        recognizer = SpeechRecognizer.createSpeechRecognizer(this).also { sr ->
            sr.setRecognitionListener(object : RecognitionListener {
                override fun onReadyForSpeech(params: Bundle?) = setStatus("Listening, Sir...")
                override fun onBeginningOfSpeech() = setStatus("I'm listening...")
                override fun onRmsChanged(rmsdB: Float) {}
                override fun onBufferReceived(buffer: ByteArray?) {}
                override fun onEndOfSpeech() = setStatus("Processing your voice...")
                override fun onError(error: Int) {
                    if (sessionActive) {
                        setStatus("Voice clear nahi aayi. Dobara boliye...")
                        listenAgain()
                    }
                }
                override fun onResults(results: Bundle?) {
                    val said = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                        ?.firstOrNull()?.trim().orEmpty()
                    if (said.isNotBlank() && sessionActive) askJarvis(said)
                    else if (sessionActive) listenAgain()
                }
                override fun onPartialResults(partialResults: Bundle?) {}
                override fun onEvent(eventType: Int, params: Bundle?) {}
            })
        }
    }

    private fun startSession() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO)
            != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.RECORD_AUDIO), 100)
            return
        }
        if (recognizer == null) createRecognizer()
        sessionActive = true
        startButton.isEnabled = false
        stopButton.isEnabled = true
        listenAgain()
    }

    private fun listenAgain() {
        if (!sessionActive || isFinishing) return
        runOnUiThread {
            try {
                val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                    putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                    putExtra(RecognizerIntent.EXTRA_LANGUAGE, "hi-IN")
                    putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "hi-IN")
                    putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false)
                    putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
                }
                recognizer?.startListening(intent)
            } catch (_: Exception) {
                setStatus("Listening start nahi ho paayi. Please try again.")
            }
        }
    }

    private fun askJarvis(userText: String) {
        setStatus("You said: $userText\n\nJARVIS is thinking...")
        executor.execute {
            var reply = "Maaf kijiye Sir, server se connect nahi ho paaya."
            try {
                val connection = (URL("${BuildConfig.BACKEND_URL}/ask").openConnection() as HttpURLConnection).apply {
                    requestMethod = "POST"
                    connectTimeout = 15000
                    readTimeout = 65000
                    doOutput = true
                    setRequestProperty("Content-Type", "application/json; charset=utf-8")
                }
                val body = JSONObject().put("session_id", sessionId).put("text", userText).toString()
                connection.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
                val code = connection.responseCode
                val stream = if (code in 200..299) connection.inputStream else connection.errorStream
                val responseBody = stream.bufferedReader().use { it.readText() }
                if (code in 200..299) reply = JSONObject(responseBody).optString("reply", reply)
                connection.disconnect()
            } catch (_: Exception) { }
            val finalReply = reply
            runOnUiThread {
                if (!sessionActive) return@runOnUiThread
                setStatus("JARVIS: $finalReply")
                speak(finalReply)
            }
        }
    }

    private fun speak(message: String) {
        if (!ttsReady) {
            setStatus("$message\n\nVoice engine is initializing.")
            listenAgain()
            return
        }
        tts?.speak(message, TextToSpeech.QUEUE_FLUSH, null, "jarvis_reply")
    }

    override fun onInit(statusCode: Int) {
        if (statusCode == TextToSpeech.SUCCESS) {
            ttsReady = true
            val result = tts?.setLanguage(Locale("hi", "IN"))
            if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) {
                tts?.setLanguage(Locale.US)
            }
            tts?.setSpeechRate(0.96f)
            tts?.setOnUtteranceProgressListener(object : android.speech.tts.UtteranceProgressListener() {
                override fun onStart(utteranceId: String?) {}
                override fun onDone(utteranceId: String?) {
                    if (sessionActive) runOnUiThread { listenAgain() }
                }
                @Deprecated("Deprecated in Java")
                override fun onError(utteranceId: String?) {
                    if (sessionActive) runOnUiThread { listenAgain() }
                }
            })
        }
    }

    private fun stopSession() {
        sessionActive = false
        try { recognizer?.cancel() } catch (_: Exception) {}
        tts?.stop()
        startButton.isEnabled = true
        stopButton.isEnabled = false
        setStatus("Voice session stopped. I'll be here when you need me, Sir.")
    }

    private fun setStatus(message: String) {
        runOnUiThread { if (::status.isInitialized) status.text = message }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 100 && grantResults.firstOrNull() == PackageManager.PERMISSION_GRANTED) {
            createRecognizer()
            setStatus("Microphone permission granted. Ready, Sir.")
        } else if (requestCode == 100) {
            setStatus("Microphone permission is required for voice interaction.")
        }
    }

    override fun onDestroy() {
        sessionActive = false
        recognizer?.destroy()
        tts?.stop()
        tts?.shutdown()
        executor.shutdownNow()
        super.onDestroy()
    }
}
