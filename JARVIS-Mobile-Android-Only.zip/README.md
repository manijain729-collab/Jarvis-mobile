# JARVIS Mobile — Android-only setup

This edition is designed for someone who has only an Android phone.
- GitHub Actions builds the Android APK in the cloud.
- Termux runs a lightweight Python backend locally on the same phone.
- The Android app sends recognized speech to `http://127.0.0.1:8000`.
- Android TextToSpeech speaks the answer.

## Requirements
- Android 8.0+ (API 26+)
- Internet connection
- GitHub account
- OpenAI API key with API access/billing enabled

## 1. Build the APK using GitHub (phone browser)
1. Sign in at https://github.com and create a new **public** repository named `jarvis-mobile`.
   Public is simplest for GitHub Actions on a free account. Do not upload any `.env` file or API key.
2. Download and extract this ZIP on your phone using your file manager.
3. In the GitHub repository, use **Add file > Upload files** and upload the contents of this folder
   (the `android` folder and `.github` folder must be at the repository root). Commit the upload.
4. Open the repository's **Actions** tab. If prompted, enable GitHub Actions.
5. Select **Build JARVIS APK**, then **Run workflow** if it did not start automatically.
6. Wait for the workflow to finish successfully. Open the completed run and download the
   `jarvis-debug-apk` artifact. Extract it and install `app-debug.apk`.
7. If Android asks, allow your browser/file manager to install unknown apps for this installation.

GitHub artifact downloads may require signing in. Keep the repository free of secrets.

## 2. Install Termux and start the backend
1. Install Termux from F-Droid: https://f-droid.org/packages/com.termux/
   Avoid mixing Termux installs from different sources.
2. Open Termux and run these commands one at a time:

   `pkg update -y && pkg upgrade -y`

   `pkg install python nano -y`

   `mkdir -p ~/jarvis && cd ~/jarvis`

3. Create the backend file:

   `nano main.py`

4. Paste the contents of `backend/main.py` from this project into nano.
5. Save in nano: press **CTRL+O**, Enter, then **CTRL+X**.
6. Set your API key in Termux (replace the example with your own key):

   `export OPENAI_API_KEY='YOUR_API_KEY_HERE'`

   `export OPENAI_MODEL='gpt-6-luna'`

7. Start the backend:

   `python main.py`

Keep Termux open and running while you use JARVIS. Do not share your API key or paste it into GitHub.

## 3. Use JARVIS
1. Open the installed JARVIS app.
2. Grant microphone permission.
3. Tap **START LISTENING**.
4. Speak naturally in Hindi, English, or Hinglish.
5. Tap **STOP** to end the session.

Both Termux and JARVIS must remain running. Android battery optimization may stop Termux in the background; for testing, keep Termux open or set its battery use to Unrestricted if your phone offers that setting.

## Troubleshooting
- Backend connection error: check Termux is still showing `JARVIS backend listening on 0.0.0.0:8000`.
- API error: check the key, API account billing/limits, and model access.
- Speech recognition failure: check microphone permission and Android speech service/network.
- No spoken response: increase media volume and check Android Text-to-Speech settings.

## Privacy and safety
Speech recognition is provided by the phone's configured speech service. Recognized text is sent to the local Termux backend and then to OpenAI's API. The API key is held in the Termux shell environment, not in the APK or GitHub repository. Do not speak passwords, OTPs, payment details, or other sensitive information.
